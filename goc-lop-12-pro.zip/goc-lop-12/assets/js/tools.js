"use strict";

document.addEventListener("DOMContentLoaded", () => {
  // To-do list: saved only in this browser using localStorage.
  const taskForm = document.getElementById("task-form");
  if (taskForm) {
    const input = document.getElementById("task-input");
    const list = document.getElementById("task-list");
    const empty = document.getElementById("task-empty");
    const count = document.getElementById("task-count");
    const clearButton = document.getElementById("clear-completed");
    let tasks = [];

    try { tasks = JSON.parse(localStorage.getItem("goc-lop-12-tasks") || "[]"); if (!Array.isArray(tasks)) tasks=[]; }
    catch { tasks=[]; }

    function save(){try{localStorage.setItem("goc-lop-12-tasks",JSON.stringify(tasks));}catch{ /* local storage may be disabled */ }}
    function render(){
      list.replaceChildren();
      tasks.forEach((task)=>{
        const li=document.createElement("li");li.className=`task-item${task.done?" done":""}`;
        const checkbox=document.createElement("input");checkbox.type="checkbox";checkbox.checked=Boolean(task.done);checkbox.setAttribute("aria-label",`Đánh dấu hoàn thành: ${task.text}`);
        checkbox.addEventListener("change",()=>{task.done=checkbox.checked;save();render();});
        const text=document.createElement("span");text.textContent=task.text;
        const remove=document.createElement("button");remove.type="button";remove.className="task-delete";remove.textContent="×";remove.setAttribute("aria-label",`Xóa: ${task.text}`);remove.addEventListener("click",()=>{tasks=tasks.filter((item)=>item.id!==task.id);save();render();});
        li.append(checkbox,text,remove);list.appendChild(li);
      });
      const pending=tasks.filter((task)=>!task.done).length;
      count.textContent=`${pending} việc cần làm`;
      empty.hidden=tasks.length>0;
    }
    taskForm.addEventListener("submit",(event)=>{event.preventDefault();const text=input.value.trim();if(!text)return;tasks.push({id:`${Date.now()}-${Math.random().toString(16).slice(2)}`,text,done:false});input.value="";save();render();input.focus();});
    clearButton.addEventListener("click",()=>{tasks=tasks.filter((task)=>!task.done);save();render();});
    render();
  }

  // Focus timer: setInterval is started only while the timer is running.
  const display=document.getElementById("timer-display");
  if(display){
    const label=document.getElementById("timer-label");const startButton=document.getElementById("timer-start");const resetButton=document.getElementById("timer-reset");const status=document.getElementById("timer-status");const presets=[...document.querySelectorAll(".timer-preset")];let duration=25*60;let remaining=duration;let interval=null;let running=false;
    const format=(seconds)=>`${String(Math.floor(seconds/60)).padStart(2,"0")}:${String(seconds%60).padStart(2,"0")}`;
    function draw(){display.textContent=format(remaining);document.title=`${format(remaining)} · Công cụ học tập | GÓC LỚP 12`;}
    function stop(){if(interval!==null){clearInterval(interval);interval=null;}running=false;startButton.textContent="Tiếp tục";}
    function tick(){remaining=Math.max(0,remaining-1);draw();if(remaining===0){stop();label.textContent="ĐÃ HẾT THỜI GIAN";status.textContent="Khoảng thời gian đã kết thúc. Bạn có thể nghỉ ngắn hoặc bắt đầu phiên mới.";startButton.textContent="Bắt đầu lại";display.classList.add("timer-finished");}}
    presets.forEach((button)=>button.addEventListener("click",()=>{stop();duration=Number(button.dataset.minutes)*60;remaining=duration;presets.forEach((b)=>b.classList.toggle("is-active",b===button));label.textContent=Number(button.dataset.minutes)<=5?"SẴN SÀNG NGHỈ NGẮN":Number(button.dataset.minutes)===15?"SẴN SÀNG NGHỈ DÀI":"SẴN SÀNG TẬP TRUNG";status.textContent="Khi bắt đầu, hãy chọn một việc duy nhất để làm.";startButton.textContent="Bắt đầu";display.classList.remove("timer-finished");draw();}));
    startButton.addEventListener("click",()=>{display.classList.remove("timer-finished");if(remaining===0){remaining=duration;}if(running){stop();label.textContent="ĐÃ TẠM DỪNG";status.textContent="Đồng hồ đã tạm dừng. Tiếp tục khi bạn sẵn sàng.";return;}running=true;startButton.textContent="Tạm dừng";label.textContent="ĐANG CHẠY";status.textContent="Bạn có thể rời trang nếu muốn, nhưng đồng hồ sẽ dừng khi trình duyệt đóng trang.";interval=setInterval(tick,1000);});
    resetButton.addEventListener("click",()=>{stop();remaining=duration;label.textContent="SẴN SÀNG TẬP TRUNG";startButton.textContent="Bắt đầu";status.textContent="Đồng hồ đã được đặt lại.";display.classList.remove("timer-finished");draw();});
    draw();
  }
});
