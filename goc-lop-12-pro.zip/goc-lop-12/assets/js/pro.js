"use strict";
/* GÓC LỚP 12 — lớp nâng cấp "Pro". Mọi dữ liệu chỉ lưu trong trình duyệt. */
(() => {
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* bỏ qua */ } }
  };
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const $ = (s, r = document) => r.querySelector(s);

  document.addEventListener("DOMContentLoaded", () => {
    /* Dark mode */
    const root = document.documentElement;
    const header = $(".header-inner");
    if (header) {
      const btn = document.createElement("button");
      btn.className = "theme-toggle"; btn.type = "button";
      const paint = () => {
        const dark = root.dataset.theme === "dark";
        btn.textContent = dark ? "☀" : "☾";
        btn.setAttribute("aria-label", dark ? "Chuyển sang giao diện sáng" : "Chuyển sang giao diện tối");
      };
      btn.addEventListener("click", () => {
        root.dataset.theme = root.dataset.theme === "dark" ? "light" : "dark";
        store.set("gl12-theme", root.dataset.theme); paint();
      });
      header.appendChild(btn); paint();
    }

    /* Thanh tiến trình cuộn + nút lên đầu trang */
    const bar = document.createElement("div"); bar.className = "scroll-progress";
    const top = document.createElement("button"); top.className = "to-top"; top.type = "button";
    top.textContent = "↑"; top.setAttribute("aria-label", "Lên đầu trang");
    top.addEventListener("click", () => scrollTo({ top: 0, behavior: reduce ? "auto" : "smooth" }));
    document.body.append(bar, top);
    const onScroll = () => {
      const max = document.documentElement.scrollHeight - innerHeight;
      bar.style.width = (max > 0 ? (scrollY / max) * 100 : 0) + "%";
      top.classList.toggle("show", scrollY > 500);
    };
    addEventListener("scroll", onScroll, { passive: true }); onScroll();

    /* Hiệu ứng hiện dần khi cuộn */
    if ("IntersectionObserver" in window && !reduce) {
      root.classList.add("js-reveal");
      const io = new IntersectionObserver((es) => es.forEach((e) => {
        if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); }
      }), { threshold: 0.12 });
      document.querySelectorAll(".topic-card,.feature-card,.section-heading,.pro-card,.feature-band").forEach((el, i) => {
        el.classList.add("reveal"); el.style.setProperty("--d", (i % 4) * 0.08 + "s"); io.observe(el);
      });
    }

    /* Đếm ngược kỳ thi */
    const cd = $("#countdown");
    if (cd) {
      const target = new Date(cd.dataset.examDate).getTime();
      const out = $(".cd", cd);
      const tick = () => {
        let s = Math.max(0, Math.floor((target - Date.now()) / 1000));
        const v = [Math.floor(s / 86400), Math.floor(s / 3600) % 24, Math.floor(s / 60) % 60, s % 60];
        out.querySelectorAll("b").forEach((b, i) => { b.textContent = String(v[i]).padStart(i ? 2 : 1, "0"); });
      };
      tick(); setInterval(tick, 1000);
    }

    /* Check-in tâm trạng (lưu cục bộ, 7 ngày gần nhất) */
    const mood = $("#mood");
    if (mood) {
      const msgs = {
        1: "Hôm nay nặng nề thật. Bạn không cần gồng — thử nghỉ vài phút, hoặc nói với một người bạn tin tưởng.",
        2: "Hơi mệt và chênh vênh cũng là bình thường. Chọn một việc nhỏ thôi, làm xong rồi nghỉ.",
        3: "Ổn ổn là đủ rồi. Giữ nhịp đều, đừng so với người khác.",
        4: "Tốt quá! Tận dụng năng lượng này cho một việc bạn đã trì hoãn nhé.",
        5: "Tuyệt vời! Nhớ ghi lại điều gì đã giúp bạn thấy vậy."
      };
      const msg = $(".mood-msg", mood), hist = $(".mood-hist", mood);
      const today = new Date().toISOString().slice(0, 10);
      const draw = () => {
        const log = store.get("gl12-mood", {});
        hist.innerHTML = "";
        for (let i = 6; i >= 0; i--) {
          const d = new Date(Date.now() - i * 864e5).toISOString().slice(0, 10);
          const n = log[d] || 0, el = document.createElement("i");
          el.style.height = n ? 4 + n * 4 + "px" : "4px"; el.title = d + (n ? " · " + n + "/5" : " · chưa ghi");
          if (n) el.style.background = n <= 2 ? "#e8a33d" : "#24ad7a";
          hist.appendChild(el);
        }
        mood.querySelectorAll(".moods button").forEach((b) => b.setAttribute("aria-pressed", String(log[today] === +b.dataset.v)));
      };
      mood.querySelectorAll(".moods button").forEach((b) => b.addEventListener("click", () => {
        const log = store.get("gl12-mood", {}); log[today] = +b.dataset.v;
        Object.keys(log).sort().slice(0, -30).forEach((k) => delete log[k]);
        store.set("gl12-mood", log);
        msg.innerHTML = msgs[b.dataset.v] + (b.dataset.v <= 2 ? ' <a href="goc-hoc-sinh.html"><b>Vào Góc học sinh →</b></a> · <a href="tim-ho-tro.html"><b>Tìm hỗ trợ →</b></a>' : "");
        draw();
      }));
      draw();
    }

    /* Câu nhắn nhủ mỗi ngày */
    const q = $("#quote");
    if (q) {
      const list = [
        "Một bước nhỏ hôm nay vẫn tốt hơn một kế hoạch hoàn hảo không bao giờ bắt đầu.",
        "Điểm số là một con số. Bạn là cả một con người.",
        "Nghỉ ngơi không phải lười biếng, đó là một phần của việc học.",
        "Không biết mình muốn gì lúc 17–18 tuổi là chuyện rất bình thường.",
        "So sánh với chính mình của tuần trước, đừng so với người khác.",
        "Hỏi xin giúp đỡ là dấu hiệu của sự trưởng thành.",
        "Ngủ đủ giấc đôi khi hiệu quả hơn thức thêm một tiếng.",
        "Bạn đã vượt qua nhiều ngày khó khăn rồi. Hôm nay cũng sẽ qua."
      ];
      const text = $(".quote-text", q);
      let i = Math.floor(Date.now() / 864e5) % list.length;
      const show = () => { text.textContent = "“" + list[i] + "”"; };
      $(".link-btn", q).addEventListener("click", () => { i = (i + 1) % list.length; show(); });
      show();
    }
  });
})();
