"use strict";

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("support-form");
  if (!form) return;

  const messageInput = document.getElementById("support-message");
  const moodInput = document.getElementById("support-mood");
  const count = document.getElementById("support-char-count");
  const status = document.getElementById("support-status");
  const result = document.getElementById("support-result");
  const title = document.getElementById("support-result-title");
  const intro = document.getElementById("support-result-intro");
  const steps = document.getElementById("support-result-steps");
  const reset = document.getElementById("support-result-reset");
  const reminder = document.getElementById("support-result-reminder");
  const copyButton = document.getElementById("support-copy-plan");
  const newButton = document.getElementById("support-start-over");
  const copyStatus = document.getElementById("support-copy-status");
  const speakButton = document.getElementById("support-speak");
  const stopSpeakButton = document.getElementById("support-stop-speak");
  const speechStatus = document.getElementById("support-speech-status");
  const moodButtons = [...document.querySelectorAll(".mood-option")];

  const topics = {
    study: {title:"Mình cùng gỡ từng nút thắt học tập nhé.", intro:"Khi bài vở và kỳ vọng dồn lại, mọi thứ có thể trông lớn hơn khả năng xử lý hiện tại. Bạn không cần giải quyết tất cả cùng một lúc.", steps:["Liệt kê những việc học đang khiến bạn lo, rồi chọn một việc quan trọng nhất.","Chia việc đó thành nhiệm vụ nhỏ, có thể làm trong 15–25 phút.","Sau khi hoàn thành, nghỉ ngắn. Nếu bị hổng kiến thức, hỏi thầy cô hoặc bạn học."], reset:"Tạm đặt sách xuống, thả lỏng vai và cảm nhận bàn chân chạm sàn. Hít thở theo nhịp tự nhiên, rồi chọn một việc nhỏ để bắt đầu.", reminder:"Một điểm số cho biết phần kiến thức nào cần cải thiện; nó không thể mô tả toàn bộ năng lực hay giá trị của bạn."},
    mind: {title:"Cảm xúc của bạn cũng xứng đáng được lắng nghe.", intro:"Lo lắng, buồn bã hay căng thẳng không khiến bạn yếu đuối. Bạn không cần giả vờ ổn hoặc tìm ra câu trả lời ngay lập tức.", steps:["Thử gọi tên cảm xúc đang có, dù chỉ bằng một hoặc hai từ.","Viết ra điều khiến bạn nặng lòng và điều bạn đang cần nhất.","Chia sẻ với người đáng tin cậy. Nếu khó khăn kéo dài hoặc ảnh hưởng sinh hoạt, hãy tìm người lớn hoặc chuyên viên phù hợp."], reset:"Tạm ngừng việc đang làm, nhìn quanh và nhận biết vài thứ bạn nhìn thấy. Thở nhẹ nhàng theo nhịp dễ chịu; dừng lại nếu bài tập khiến bạn không thoải mái.", reminder:"Bạn không phải lúc nào cũng cần tự mình vượt qua. Nhờ người khác lắng nghe là một lựa chọn đáng trân trọng."},
    future: {title:"Bạn chưa cần biết hết tương lai ngay hôm nay.", intro:"Chọn ngành, chọn trường và nghĩ về con đường sau lớp 12 có thể gây áp lực. Không biết câu trả lời ngay lúc này là điều bình thường.", steps:["Ghi lại môn học, hoạt động hoặc lĩnh vực khiến bạn tò mò.","Chọn hai hoặc ba ngành để tìm hiểu chương trình học và yêu cầu tuyển sinh từ nguồn chính thức.","Trò chuyện với giáo viên hướng nghiệp, gia đình hoặc người đang học ngành đó."], reset:"Tạm đổi câu hỏi “Mình phải làm gì cả đời?” thành “Tuần này mình muốn tìm hiểu điều gì?”. Câu hỏi nhỏ hơn thường dễ bắt đầu hơn.", reminder:"Hướng đi có thể dần rõ ràng qua trải nghiệm. Đừng bắt bản thân phải có mọi câu trả lời ngay."},
    family: {title:"Mong muốn của bạn cũng cần được lắng nghe.", intro:"Khi kỳ vọng gia đình khác với suy nghĩ của mình, bạn có thể thấy khó xử. Cảm xúc và nguyện vọng của bạn đáng được xem xét nghiêm túc.", steps:["Xác định một điều cụ thể bạn muốn gia đình hiểu.","Chọn lúc mọi người bình tĩnh và nói bằng câu “Con cảm thấy…” hoặc “Con đang cần…”.","Nếu khó trò chuyện trực tiếp, hãy viết ra suy nghĩ hoặc nhờ người lớn đáng tin cậy hỗ trợ."], reset:"Viết riêng điều bạn có thể chủ động và điều nằm ngoài quyền kiểm soát. Bạn chỉ cần bắt đầu từ phần mình có thể tác động.", reminder:"Bạn có thể tôn trọng gia đình mà vẫn có suy nghĩ và mong muốn riêng."},
    friends: {title:"Bạn xứng đáng có những mối quan hệ tôn trọng mình.", intro:"Hiểu lầm, xung đột hoặc cảm giác bị bỏ lại có thể khiến bạn tổn thương. Bạn không cần chiều lòng tất cả mọi người để chứng minh mình đáng quý.", steps:["Xác định điều khiến bạn buồn nhất, tách sự việc khỏi điều bạn lo có thể xảy ra.","Nếu cảm thấy an toàn, chọn thời điểm bình tĩnh để chia sẻ và lắng nghe nhau.","Nếu có xúc phạm, đe dọa hoặc bắt nạt lặp lại, tìm giáo viên hay người lớn đáng tin cậy."], reset:"Tạm rời cuộc trò chuyện khiến bạn căng thẳng. Làm một việc nhẹ nhàng, rồi quay lại vấn đề khi đã sẵn sàng.", reminder:"Bạn có quyền đặt giới hạn và tìm những mối quan hệ khiến mình cảm thấy an toàn."},
    other: {title:"Cảm ơn bạn đã dành thời gian chia sẻ.", intro:"Có thể vấn đề chưa nằm gọn trong một chủ đề nào, hoặc bạn chưa biết gọi tên nó ra sao. Bạn không cần sắp xếp mọi suy nghĩ thật hoàn hảo mới được tìm kiếm hỗ trợ.", steps:["Viết ngắn gọn điều đang khiến bạn bận tâm, kể cả khi suy nghĩ còn lộn xộn.","Tự hỏi điều gì sẽ giúp mình dễ chịu hơn một chút trong hôm nay.","Nếu vấn đề vượt quá khả năng tự giải quyết, tìm người đáng tin cậy để cùng cân nhắc lựa chọn."], reset:"Tạm bỏ nhu cầu phải tìm ngay lời giải. Ngồi thoải mái, thở tự nhiên và để suy nghĩ chậm lại một chút.", reminder:"Bạn không cần có sẵn câu trả lời cho mọi chuyện mới có thể tiến về phía trước."}
  };

  const moods = {
    overwhelmed:{intro:"Có vẻ nhiều việc đang dồn lại cùng lúc.", first:"Liệt kê những việc đang dồn lại, rồi khoanh một việc nhỏ có thể bắt đầu trước."},
    anxious:{intro:"Khi lo lắng xuất hiện, tâm trí có thể nghĩ đến nhiều khả năng cùng lúc.", first:"Chia giấy thành hai phần: điều mình biết chắc và điều mình đang lo sẽ xảy ra. Xem điều gì có thể kiểm tra."},
    tired:{intro:"Mệt mỏi có thể khiến bắt đầu công việc khó hơn.", first:"Kiểm tra xem mình đã có thời gian nghỉ, ăn uống và uống nước chưa. Nếu có thể, tạm hoãn một việc chưa cấp thiết."},
    confused:{intro:"Bạn chưa cần ép mình hiểu rõ mọi chuyện ngay lập tức.", first:"Viết ra câu hỏi khiến bạn bối rối nhất và chọn một câu để tìm hiểu trước."},
    lonely:{intro:"Cảm thấy cô đơn có thể khó chịu ngay cả khi xung quanh có người.", first:"Nghĩ đến một người bạn tương đối tin tưởng và thử nhắn rằng bạn muốn trò chuyện hoặc cần người lắng nghe."},
    okay:{intro:"Thật tốt khi bạn có chút khoảng trống để nhìn lại tình hình.", first:"Chọn một thói quen nhỏ có ích hôm nay, như sắp xếp góc học tập hoặc trò chuyện với người thân."}
  };

  function normalize(text) {
    return String(text || "").toLocaleLowerCase("vi").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d");
  }
  function hasAny(text, terms) { return terms.some((term) => text.includes(term)); }
  function chosenTopic() { return form.querySelector('input[name="topic"]:checked')?.value || "study"; }
  function setStatus(text, error=false) { status.textContent=text; status.classList.toggle("is-error",error); }
  function makeList(items) { steps.replaceChildren(); items.forEach((item) => { const li=document.createElement("li"); li.textContent=item; steps.appendChild(li); }); }

  function buildAdvice(topic, mood, message) {
    const base = topics[topic] || topics.other;
    const moodData = moods[mood] || moods.overwhelmed;
    const normalized = normalize(message);
    const advice = { title:base.title, intro:`${base.intro} ${moodData.intro}`, steps:[...base.steps], reset:base.reset, reminder:base.reminder };
    advice.steps[0] = moodData.first;

    if (hasAny(normalized,["thi cu","kiem tra","diem so","de thi","thi tot nghiep"])) advice.steps[1]="Nếu đang lo về bài thi hoặc điểm số, hãy chọn một nội dung cụ thể để ôn, xem lại lỗi sai và hỏi thầy cô về phần chưa hiểu.";
    if (hasAny(normalized,["chon nganh","chon truong","nghe nghiep","tuyen sinh","tuong lai"])) advice.steps[1]="Chọn một ngành hoặc trường đang cân nhắc rồi kiểm tra thông tin tuyển sinh, chương trình học và yêu cầu chính thức.";
    if (hasAny(normalized,["mat ngu","kho ngu","met moi","met qua","kiem suc"])) advice.steps[0]="Hãy kiểm tra xem mình có đang thiếu nghỉ ngơi hoặc ăn uống không. Nếu có thể, giảm một việc chưa cấp thiết và nhờ người khác hỗ trợ.";
    if (hasAny(normalized,["khong biet bat dau","khong biet lam gi","qua nhieu viec"])) advice.steps[0]="Chọn một việc nhỏ, ít tốn thời gian nhưng có ích. Bạn chỉ cần bắt đầu với bước đầu tiên.";

    const safetyTerms=["khong muon song","muon chet","muon bien mat","khong muon ton tai","tu lam hai ban than","lam hai ban than","muon tu tu","tu tu","ket thuc cuoc doi"];
    if (hasAny(normalized,safetyTerms)) return {
      priority:true,
      title:"Bạn không cần phải đối mặt với chuyện này một mình.",
      intro:"Mình rất tiếc vì bạn đang trải qua cảm giác nặng nề như vậy. Website không thể thay thế hỗ trợ trực tiếp, nhưng bạn xứng đáng được lắng nghe và có người ở bên giúp đỡ.",
      steps:["Hãy đến gần một người lớn đáng tin cậy ở gần bạn, chẳng hạn người thân, giáo viên hoặc nhân viên nhà trường, và nói rằng bạn đang cần giúp đỡ.","Nếu khó diễn đạt, bạn có thể nói: “Mình đang rất không ổn. Mình cần bạn ở bên và giúp mình tìm người hỗ trợ.”","Nếu bạn đang có nguy cơ bị tổn thương ngay lúc này, hãy đến nơi có người và nhờ người lớn gần bạn liên hệ dịch vụ khẩn cấp tại nơi bạn sống."],
      reset:"Đừng cố tự giải quyết mọi chuyện một mình trong khoảnh khắc này. Hãy ưu tiên ở gần một người có thể hỗ trợ trực tiếp.",
      reminder:"Bạn xứng đáng được giúp đỡ bởi một người thật sự có thể ở bên. Đừng chỉ dựa vào phản hồi tự động của website trong tình huống khẩn cấp."
    };
    return advice;
  }

  moodButtons.forEach((button) => button.addEventListener("click", () => {
    moodButtons.forEach((item) => { const selected=item===button; item.classList.toggle("is-selected",selected); item.setAttribute("aria-pressed",String(selected)); });
    moodInput.value=button.dataset.mood || "overwhelmed";
  }));

  function updateCount(){count.textContent=`${messageInput.value.length}/2000`;}
  messageInput.addEventListener("input",()=>{updateCount();if(status.textContent)setStatus("");});
  updateCount();

  form.addEventListener("submit",(event)=>{
    event.preventDefault();
    const message=messageInput.value.trim();
    if(message.length<5){setStatus("Bạn chia sẻ thêm một chút nhé (ít nhất 5 ký tự).",true);messageInput.focus();return;}
    const advice=buildAdvice(chosenTopic(),moodInput.value,message);
    title.textContent=advice.title;intro.textContent=advice.intro;reset.textContent=advice.reset;reminder.textContent=advice.reminder;makeList(advice.steps);
    result.hidden=false;result.classList.toggle("priority-result",Boolean(advice.priority));
    setStatus("Đã tạo gợi ý cho bạn. Hãy chọn những điều phù hợp với hoàn cảnh của mình.");copyStatus.textContent="";
    result.scrollIntoView({behavior:matchMedia("(prefers-reduced-motion: reduce)").matches?"auto":"smooth",block:"start"});
  });

  function stopReading() {
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
    if (speakButton) speakButton.disabled = false;
    if (stopSpeakButton) stopSpeakButton.disabled = true;
  }

  if (speakButton && stopSpeakButton) {
    if (!("speechSynthesis" in window) || !("SpeechSynthesisUtterance" in window)) {
      speakButton.disabled = true;
      speakButton.title = "Trình duyệt này chưa hỗ trợ đọc văn bản.";
      if (speechStatus) speechStatus.textContent = "Trình duyệt chưa hỗ trợ tính năng đọc gợi ý. Bạn vẫn có thể đọc nội dung trên màn hình.";
    } else {
      speakButton.addEventListener("click", () => {
        stopReading();
        const spokenText = [
          title.textContent,
          intro.textContent,
          "Ba bước bạn có thể thử.",
          ...[...steps.querySelectorAll("li")].map((item, index) => `Bước ${index + 1}. ${item.textContent}`),
          "Một phút cho chính mình.",
          reset.textContent,
          reminder.textContent
        ].join(". ");
        const utterance = new SpeechSynthesisUtterance(spokenText);
        utterance.lang = "vi-VN";
        utterance.rate = 0.96;
        utterance.pitch = 1;
        utterance.onstart = () => {
          speakButton.disabled = true;
          stopSpeakButton.disabled = false;
          if (speechStatus) speechStatus.textContent = "Đang đọc gợi ý…";
        };
        utterance.onend = () => {
          speakButton.disabled = false;
          stopSpeakButton.disabled = true;
          if (speechStatus) speechStatus.textContent = "Đã đọc xong gợi ý.";
        };
        utterance.onerror = () => {
          speakButton.disabled = false;
          stopSpeakButton.disabled = true;
          if (speechStatus) speechStatus.textContent = "Không thể phát giọng đọc lúc này. Bạn có thể thử lại.";
        };
        window.speechSynthesis.speak(utterance);
      });
      stopSpeakButton.addEventListener("click", () => {
        stopReading();
        if (speechStatus) speechStatus.textContent = "Đã dừng đọc.";
      });
    }
  }

  copyButton.addEventListener("click",async()=>{
    const plan=[title.textContent,"",intro.textContent,"","KẾ HOẠCH NHỎ",...[...steps.querySelectorAll("li")].map((li,i)=>`${i+1}. ${li.textContent}`),"","KHOẢNG NGHỈ",reset.textContent,"",reminder.textContent].join("\n");
    try {
      if(navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(plan);
      else {const area=document.createElement("textarea");area.value=plan;area.style.position="fixed";area.style.opacity="0";document.body.appendChild(area);area.select();const ok=document.execCommand("copy");area.remove();if(!ok)throw new Error("copy failed");}
      copyStatus.textContent="Đã sao chép kế hoạch.";copyStatus.classList.remove("is-error");
    } catch {copyStatus.textContent="Chưa sao chép được. Bạn có thể chọn và sao chép nội dung bằng tay.";copyStatus.classList.add("is-error");}
  });

  newButton.addEventListener("click",()=>{
    stopReading();
    if (speechStatus) speechStatus.textContent = "";
    form.reset();moodInput.value="overwhelmed";
    moodButtons.forEach((button)=>{const selected=button.dataset.mood==="overwhelmed";button.classList.toggle("is-selected",selected);button.setAttribute("aria-pressed",String(selected));});
    result.hidden=true;result.classList.remove("priority-result");setStatus("");copyStatus.textContent="";updateCount();messageInput.focus();form.scrollIntoView({behavior:"smooth",block:"start"});
  });

  window.addEventListener("pagehide", stopReading);
});
