"use strict";

document.addEventListener("DOMContentLoaded", () => {
  // Memory matching game.
  const grid = document.getElementById("memory-grid");
  if (grid) {
    const symbols = ["🌻", "📚", "🎧", "🍀", "⭐", "🧩"];
    let deck = [];
    let opened = [];
    let matched = new Set();
    let moves = 0;
    let locked = false;
    const progress = document.getElementById("memory-progress");
    const moveLabel = document.getElementById("memory-moves");
    const status = document.getElementById("memory-status");
    const restart = document.getElementById("memory-restart");

    function shuffle(items) {
      const copy = [...items];
      for (let i = copy.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [copy[i], copy[j]] = [copy[j], copy[i]];
      }
      return copy;
    }
    function render() {
      grid.replaceChildren();
      deck.forEach((symbol, index) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "memory-card";
        const isOpen = opened.includes(index) || matched.has(index);
        button.textContent = isOpen ? symbol : "?";
        button.setAttribute("aria-label", isOpen ? `Thẻ ${symbol}` : `Thẻ úp số ${index + 1}`);
        button.setAttribute("aria-pressed", String(isOpen));
        button.disabled = matched.has(index) || (locked && !opened.includes(index));
        if (matched.has(index)) button.classList.add("is-matched");
        if (isOpen) button.classList.add("is-open");
        button.addEventListener("click", () => reveal(index));
        grid.appendChild(button);
      });
      progress.textContent = `Đã tìm: ${matched.size / 2}/6 cặp`;
      moveLabel.textContent = `Lượt: ${moves}`;
    }
    function reveal(index) {
      if (locked || matched.has(index) || opened.includes(index)) return;
      opened.push(index);
      if (opened.length === 2) {
        moves += 1;
        locked = true;
        const [a, b] = opened;
        if (deck[a] === deck[b]) {
          matched.add(a); matched.add(b); opened = []; locked = false;
          status.textContent = matched.size === deck.length ? `Hoàn thành trong ${moves} lượt. Chúc mừng bạn!` : "Tìm được một cặp rồi! Tiếp tục nhé.";
          render();
        } else {
          status.textContent = "Chưa thành một cặp. Hãy thử lượt tiếp theo.";
          render();
          window.setTimeout(() => { opened = []; locked = false; render(); }, 850);
        }
      } else {
        status.textContent = "Đã lật một thẻ. Chọn thêm một thẻ nữa.";
        render();
      }
    }
    function start() {
      deck = shuffle([...symbols, ...symbols]);
      opened = []; matched = new Set(); moves = 0; locked = false;
      status.textContent = "Chọn hai thẻ để bắt đầu tìm cặp nhé.";
      render();
    }
    restart.addEventListener("click", start);
    start();
  }

  // Short, non-competitive quiz.
  const questionNode = document.getElementById("quiz-question");
  if (questionNode) {
    const questions = [
      {q:"Khi cần ghi nhớ một nội dung dài, cách nào thường hữu ích?",a:["Đọc lướt liên tục mà không nghỉ","Chia nội dung thành phần nhỏ và tự nhắc lại","Cố học tất cả trong một lần"],correct:1,why:"Chia nhỏ nội dung và chủ động nhớ lại giúp bạn kiểm tra phần đã hiểu, phần cần xem thêm."},
      {q:"Một buổi nghỉ giải lao dễ chịu có thể là gì?",a:["Đứng dậy vận động nhẹ hoặc uống nước","Tiếp tục nhìn màn hình không ngừng","Tự trách vì chưa hoàn thành mọi việc"],correct:0,why:"Một khoảng nghỉ ngắn, linh hoạt có thể giúp bạn đổi trạng thái và quay lại khi sẵn sàng."},
      {q:"Khi chưa hiểu bài, lựa chọn nào phù hợp?",a:["Giấu việc mình chưa hiểu","Bỏ luôn môn học đó","Ghi lại câu hỏi và nhờ thầy cô giải thích"],correct:2,why:"Đặt câu hỏi cụ thể giúp người hỗ trợ biết bạn đang vướng ở đâu."},
      {q:"Khi chọn ngành học, nên làm gì?",a:["Chỉ chọn theo số đông","Tìm hiểu chương trình và thông tin tuyển sinh chính thức","Quyết định chỉ từ một lời khuyên"],correct:1,why:"Thông tin chính thức và nhiều góc nhìn giúp bạn cân nhắc phù hợp hơn với hoàn cảnh của mình."}
    ];
    const number = document.getElementById("quiz-number");
    const options = document.getElementById("quiz-options");
    const feedback = document.getElementById("quiz-feedback");
    const next = document.getElementById("quiz-next");
    let current = 0;
    let answered = false;
    function showQuestion() {
      const item = questions[current];
      number.textContent = `CÂU ${current + 1}/${questions.length}`;
      questionNode.textContent = item.q;
      options.replaceChildren();
      item.a.forEach((answer, index) => {
        const button = document.createElement("button");
        button.type = "button"; button.className = "quiz-option"; button.textContent = answer;
        button.addEventListener("click", () => {
          if (answered) return;
          answered = true;
          const correct = index === item.correct;
          button.classList.add(correct ? "is-correct" : "is-wrong");
          [...options.children].forEach((other, i) => {
            other.disabled = true;
            if (i === item.correct) other.classList.add("is-correct");
          });
          feedback.textContent = `${correct ? "Chính xác! " : "Mình cùng xem lại nhé. "}${item.why}`;
          next.disabled = false;
          next.textContent = current === questions.length - 1 ? "Chơi lại từ đầu ↻" : "Câu tiếp theo →";
        });
        options.appendChild(button);
      });
      answered = false; feedback.textContent = "Chọn một đáp án để xem lời giải thích."; next.disabled = true; next.textContent = "Câu tiếp theo →";
    }
    next.addEventListener("click", () => { current = (current + 1) % questions.length; showQuestion(); });
    showQuestion();
  }

  // Random low-effort break ideas.
  const ideas = [
    ["Nghe một bản nhạc bạn yêu thích.","Dành vài phút rời mắt khỏi màn hình và tận hưởng giai điệu."],
    ["Uống một cốc nước.","Đứng dậy, uống nước và trở lại khi thấy thoải mái."],
    ["Ngắm nhìn khung cảnh bên ngoài.","Quan sát cây cối, bầu trời hoặc một chi tiết thú vị quanh bạn."],
    ["Vẽ nguệch ngoạc một hình bất kỳ.","Không cần đẹp hay đúng chủ đề; chỉ cần vui một chút."],
    ["Sắp xếp lại góc học tập.","Chọn một góc nhỏ và làm cho nó gọn gàng hơn."],
    ["Gửi lời hỏi thăm đến một người bạn.","Một tin nhắn thân thiện có thể tạo nên kết nối dễ chịu."]
  ];
  const suggestion = document.getElementById("activity-suggestion");
  if (suggestion) {
    const note = document.getElementById("activity-note");
    document.getElementById("activity-random").addEventListener("click", () => {
      const choices = ideas.filter(([title]) => title !== suggestion.textContent);
      const pick = choices[Math.floor(Math.random() * choices.length)];
      suggestion.textContent = pick[0]; note.textContent = pick[1];
    });
  }
});
